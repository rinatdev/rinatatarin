<?php 
    $email = filter_var(trim($_POST['email']),
    FILTER_SANITIZE_STRING);
    $name = filter_var(trim($_POST['name']),
    FILTER_SANITIZE_STRING);
    $pass = filter_var(trim($_POST['pass']),
    FILTER_SANITIZE_STRING);
    

    if(mb_strlen($email) < 5 || mb_strlen($email) > 90){
        echo "Недопустимая длинна емейла";
        exit();
    }else if(mb_strlen($name) < 5 || mb_strlen($name) > 50){
        echo "Недопустимая длинна логина";
        exit();
    }else if(mb_strlen($pass) < 4 || mb_strlen($pass) > 8){
        echo "Недопустимая длинна пароля(от 4 до 8 символов)";
        exit();
    }

    $pass = md5($pass."dlksfjlwfe7632619");

    $mysql = new mysqli('rinatatarin', 'root', '', 'register_db');
    
    $mysql->query("INSERT INTO `users` (`email`, `pass`, `name`) 
    VALUES('$email', '$pass', '$name')");

    $mysql->close();

    header('Location: /');
?>