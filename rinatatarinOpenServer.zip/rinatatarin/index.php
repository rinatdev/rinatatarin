<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="icon" href="img/logo.png">

    <title>Food Blog</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-1 nav_main">
        <div class="container-fluid container">
          <a class="navbar-brand" href="/">
            <img src="img/logo.png" alt="" width="70" height="70">Food Blog
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-link active" aria-current="page" href="#">Главная</a>
              <a class="nav-link" href="#">Закуски</a>
              <a class="nav-link" href="#">Салаты</a>
              <a class="nav-link" href="#" >Выпечка</a>
            </div>
          </div>
          <form class="d-flex">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
    <?php
     if($_COOKIE['user'] == ''): 
    ?>
    <div class="autorization p-2">
      <a href="signIn.php">Sign in</a>
      <a class="signUp" href="signUp.php">Sign up</a>
    </div>
    <?php else:?>
    <div class="autorization p-2">
      <a href="profile.php">Profile</a>
    </div>
    <?php endif;?>
    </div>
      </nav>

      <div class="container">
      <div class="row row-cols-1 row-cols-md-3 g-4 card_hover mt-3">
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/main-dishes/0669-yazyk/00.469187b6.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/main-dishes/0668-chickenring/00.ffa25394.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a short card.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/salads/0667-olivie/00.0477389f.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/main-dishes/0146_pasta_krevetki/00.23b6dcca.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/first-dishes/0161-mashhurda/00.4b4a0f10.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="https://blog-food.ru/cache/recipes/main-dishes/0134-sagetti/00.9b548bdb.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Название карточки</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="footer">
        <div class="links">
          <a href=""></a>
        </div>
      </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>
